# Web Bluetooth Terminal

Code base: https://github.com/loginov-rocks/Web-Bluetooth-Terminal
